# <NOME DO APP> — instruções do agente

> **Este arquivo é cópia literal do `CLAUDE.md`.** Ferramentas que leem `AGENTS.md`
> (Codex, Cursor, Gemini CLI, Copilot) precisam do conteúdo **aqui dentro**. Um ponteiro
> dizendo "as regras estão no CLAUDE.md" não carrega nada — é texto comum, e o agente
> pode simplesmente não abrir o outro arquivo.
>
> **Mudou um, mude o outro.** São dois arquivos com o mesmo texto de propósito.

<uma linha dizendo o que este app é>

## Antes de qualquer trabalho

Leia `memory-bank/estado.md`. Ele diz onde o projeto parou, o que está validado e o que
está bloqueado. Não parta de pressuposto próprio.

## Stack (decidida — não trocar sem autorização)

- Runtime: `<ex.: Node >= 22.12>`, TypeScript
- Estrutura: `packages/domain` (regra de negócio **sem framework**, com testes) ·
  `apps/<app>` · `apps/api` se houver servidor
- Alvo: **web é a versão de referência**; o app de loja é a mesma base embrulhada
  (`<ex.: Capacitor>`)

## Regras duras

- Responder em **pt-BR**.
- Nunca `git reset --hard`, `restore`, `clean`, `stash`, `rebase`, `--amend` ou force
  push. Nunca descartar trabalho preexistente.
- **Nunca declarar PASS sem ter executado.** Teste automatizado verde não é PASS de
  runtime — o portão é a plataforma-alvo real.
- Nunca gravar segredo em log, configuração versionada, evidência ou interface.
- Provedor, modelo e endereço de servidor **nunca fixos no código**.
- Não afirmar que algo funciona em plataforma que você não executou. O máximo honesto é
  *"escrito, não executado"*.
- **STOP AND REPORT** em vez de contornar bloqueio, alargar escopo ou commitar remendo.

## Fronteiras deste projeto

- **O usuário final não instala nada além do app.** Nem runtime, nem ferramenta.
- **Regra de negócio não depende de framework.** Ela sobrevive a troca de UI e de banco.
- **Nada que o usuário criou pode morar em cache** — o sistema apaga sem avisar.
- **Exportação dos dados é obrigatória**: formato aberto, sem conta e sem internet.
- Token em armazenamento seguro do sistema. **Nunca** em `localStorage`.
- **Nunca embarcar chave de provedor de IA** no app nem na web.
- `localhost` nunca fixo no código.
- Toda função central funciona **offline**. Sincronizar é bônus, nunca pré-requisito.

## Verificação

- Veja a tabela de comandos em `memory-bank/padroes.md` — use a suíte **estreita** no dia
  a dia e a completa só antes de publicar.
- **Build nativa, emulador, assinatura e envio para loja são do Dev.** Você não pode
  afirmar nada sobre Android ou iOS.

A build e o teste na plataforma-alvo são do Dev. Você entrega código e diz o que falta
verificar.

## Onde está o resto

- **Convenção de uma área só:** `.claude/rules/` — arquivo com `paths:` no topo entra no
  contexto só quando o agente mexe num arquivo que casa com o filtro.
- **Procedimento por assunto:** `.agents/skills/` — não duplique aqui.
- **Estado atual:** `memory-bank/estado.md`
- **Comandos e convenções:** `memory-bank/padroes.md`
- **Decisões e descartes:** `memory-bank/decisoes.md`

> Se este arquivo passar de duas páginas, alguma coisa aqui é skill.
