# Padrões — <APP>

O que o agente precisa saber para não perguntar duas vezes.

## Comando de teste

> O subagent `test-runner` tira o comando **daqui**. Suíte estreita no dia a dia, completa
> só antes de publicar — rodar tudo em toda verificação é caro e lento.

| Mexeu em | Rode |
|---|---|
| `packages/domain` | `npm run test:domain` |
| `packages/sync` | `npm run test:sync` |
| `apps/api` | `npm run test:api` |
| `apps/<app>` (lógica) | `npm run test:app` |
| tela | `npm run test:ui` |
| antes de publicar | `npm test` e `npm run typecheck` |

## O que conta como prova de que funciona

- **Conta:** `<ex.: teste verde + print da tela na versão web>`
- **Não conta:** teste verde sozinho; e **nada** prova Android ou iOS sem build na
  máquina do Dev.

## Revisão obrigatória

| Mexeu aqui | Então |
|---|---|
| `<arquivos que tocam dinheiro, permissão ou dado de terceiro>` | `reviewer` marca **ALTO** por padrão; não aplicar sem revisão humana, mesmo com teste verde |

## Convenções

- Nomes:
- Estrutura de pasta:
- Mensagem de commit:

## Armadilhas já pagas

| Sintoma | Causa | Conserto |
|---|---|---|
| | | |
